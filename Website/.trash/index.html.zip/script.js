$( document ).ready(function() {
 $( "#hi" ).click(function() {
    $("#alert-div").toggle();
 });
});