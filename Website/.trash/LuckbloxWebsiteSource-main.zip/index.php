<?php

header('location:login.php');

?>

<html>

    <head>

        

    </head>

</html>