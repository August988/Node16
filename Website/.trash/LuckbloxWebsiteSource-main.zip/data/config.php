<?php

$host = "sql5.freesqldatabase.com";

$dbuser = "sql5421378";

$dbpass = "ClFufFAH2a";

$dbname = "sql5421378";



$key = "09095068496835958355648768675389673896758376853693683906588685376835696586474";



$conn = mysqli_connect($host, $dbuser, $dbpass, $dbname);



if (!$conn){

    echo "failed";

}



?>