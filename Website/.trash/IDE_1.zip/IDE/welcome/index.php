<html><head>

    <title>Welcome</title>
    <script
  src="https://code.jquery.com/jquery-1.7.2.js"
  integrity="sha256-FxfqH96M63WENBok78hchTCDxmChGFlo+/lFIPcZPeI="
  crossorigin="anonymous"></script>
<script type="text/javascript">window.jQuery || document.write("<script type='text/javascript' src='https://code.jquery.com/jquery-1.7.2.js'><\/script>")</script>
<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/4.0/1/MicrosoftAjax.js"></script>
<script type="text/javascript">window.Sys || document.write("<script type='text/javascript' src='https://ajax.aspnetcdn.com/ajax/4.0/1/MicrosoftAjax.js'><\/script>")</script><script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/4.0/1/MicrosoftAjax.js"></script>
<script>
        function insertContent(id)
        {
                try
                {
                window.external.Insert("http://meb.ct8.pl/asset/?id=" + id);
                }
                catch(x)
                {
                    alert("Could not insert the requested item");
                }          
        }
</script>
    
<link rel="stylesheet" href="/static/css/IDE/baseCSS.css">

    
<script type="text/javascript" src="/static/js/mainRoblox.js"></script>

    
    <script type="text/javascript">Roblox.config.externalResources = ['/js/jquery/jquery-1.7.2.min.js'];Roblox.config.paths['jQuery'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/29cf397a226a92ca602cb139e9aae7d7.js';Roblox.config.paths['Pagelets.BestFriends'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/c8acaba4214074ed4ad6f8b4a9647038.js';Roblox.config.paths['Pages.Catalog'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/c8f61a230e6ad34193b40758f1499a3d.js';Roblox.config.paths['Pages.Messages'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/f772272ef93399adea361e94e807f79f.js';Roblox.config.paths['Resources.Messages'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/fb9cb43a34372a004b06425a1c69c9c4.js';Roblox.config.paths['Widgets.AvatarImage'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/b7f418a5fefacfd21f2c86b495b4698f.js';Roblox.config.paths['Widgets.DropdownMenu'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/d83d02dd89808934b125fa21c362bcb9.js';Roblox.config.paths['Widgets.GroupImage'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/3e692c7b60e1e28ce639184f793fdda9.js';Roblox.config.paths['Widgets.HierarchicalDropdown'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/e8b579b8e31f8e7722a5d10900191fe7.js';Roblox.config.paths['Widgets.ItemImage'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/facde7fc56e53e1ef9ee75203bc76bb4.js';Roblox.config.paths['Widgets.PlaceImage'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/08e1942c5b0ef78773b03f02bffec494.js';Roblox.config.paths['Widgets.Suggestions'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/a63d457706dfbc230cf66a9674a1ca8b.js';Roblox.config.paths['Widgets.SurveyModal'] = 'https://web.archive.org/web/20130715023235/http://jsak.roblox.com/d6e979598c460090eafb6d38231159f6.js';</script>
        <script type="text/javascript">
            function editTemplateInStudio(play_placeId) { RobloxLaunch._GoogleAnalyticsCallback = function() { var isInsideRobloxIDE = 'website'; if (Roblox && Roblox.Client && Roblox.Client.isIDE && Roblox.Client.isIDE()) { isInsideRobloxIDE = 'Studio'; };GoogleAnalyticsEvents.FireEvent(['Edit Location', 'Guest', isInsideRobloxIDE]);GoogleAnalyticsEvents.FireEvent(['Edit', 'Guest', '']); };  Roblox.Client.WaitForRoblox(function() { RobloxLaunch.StartGame('https://web.archive.org/web/20130715023235/http://www.roblox.com//Game/edit.ashx?PlaceID='+play_placeId+'&upload=', 'edit.ashx', 'https://web.archive.org/web/20130715023235/https://www.roblox.com//Login/Negotiate.ashx', 'FETCH', true); }); }
        </script>
</head>
<body id="StudioWelcomeBody">




 
    <div class="header">
      
            <div id="header-login-wrapper" class="iframe-login-signup" data-display-opened="">
                <a href="https://web.archive.org/web/20130715023235/http://www.roblox.com/Login/NewAge.aspx" target="_blank" class="GrayButton translate" id="header-signup"><span>Sign Up</span></a>
                <span id="header-or">or</span>
                <span class="studioiFrameLogin">
                    <span id="login-span">
                        <a id="header-login" class="btn-control btn-control-large">Login <span class="grey-arrow">▼</span></a>
                    </span>
                
                    <div id="iFrameLogin" class="studioiFrameLogin" style="display: none; height: 128px;">
                        <iframe class="login-frame" src="https://meb.ct8.pl/Login/iFrameLogin.php?loginRedirect=True&parentUrl=http%3a%2f%2fwww.roblox.com%2fIDE%2fwelcome" scrolling="no" frameborder="0" data-ruffle-polyfilled=""></iframe>                                  
                    </div>
                </span>
            </div>
        <!-- This is only after the login stuff because IE7 demands floated elements be before non-floated -->
        <img src="/static/img/studioLOGO.png" alt="Meblox Studio Title">
        <p id="HomeLink">
            <a class="text-link" href="/Build/Default.php">Switch to Classic View</a>
        </p>
    </div>
    <div class="container">
        <div class="navbar" style="height: 841px;">
            <ul class="navlist" style="border-bottom: none;">
                <li id="NewProject" class="navselected"><p>New Project</p></li>
                    <li id="MyProjects" class="lastnav"><p>My Projects</p></li>
                <!--li class="lastnav"><p>Recent News</p></li-->
            </ul>
        </div>
        <div class="main">
            <div id="TemplatesView" class="welcome-content-area">

<h2 id="StudioGameTemplates">GAME TEMPLATES</h2>
            <div class="templatetypes">
                <ul class="templatetypes">
                        <li js-data-templatetype="Basic" class="selectedType"><a href="#Basic">Basic</a></li>
                        <li js-data-templatetype="Strategy"><a href="#Strategy">Strategy</a></li>
                        <li js-data-templatetype="Action"><a href="#Action">Action</a></li>
                </ul>
                <!--div class="tool-tip">
                    <img alt="Recommended for users new to ROBLOX studio" src="/images/IDE/img-tail-top.png" class="top" />
                    <p>Recommended for users new to ROBLOX studio</p>
                    <a class="closeButton"></a>
                </div -->
            </div>
            
                <div class="templates" js-data-templatetype="Basic" style="display: block;">
                        <div class="template" placeid="95206881">
                            <a class="game-image" onclick="insertContent(95206881)"><img class="" src="/static/img/362ae9c43957047a0287f9cd2c98646c.png"></a>
                            <p>Baseplate</p>
                        </div>
                        <div class="template" placeid="95206881">
                            <a class="game-image"><img class="" src="/static/img/362ae9c43957047a0287f9cd2c98646c.png"></a>
                            <p>Baseplate</p>
                        </div>
                        <div class="template" placeid="95206192">
                            <a class="game-image"><img class="" src="/static/img/ab99a6e34406eb5e7aebd349c90ce35b.png"></a>
                            <p>Flat Terrain</p>
                        </div>
                </div>
                <div class="templates" js-data-templatetype="Strategy">
                        <div class="template" placeid="92721754">
                            <a class="game-image"><img class="" src="/static/img/2db15742ba86f0dfe6cd2762a8debbde.png"></a>
                            <p>Capture The Flag</p>
                        </div>
                        <div class="template" placeid="95269276">
                            <a class="game-image"><img class="" src="/static/img/426308e89cd36c0bb531b9dd8e990c10.png"></a>
                            <p>Control Points</p>
                        </div>
                </div>
                <div class="templates" js-data-templatetype="Action">
                        <div class="template" placeid="92721884">
                            <a class="game-image"><img class="" src="/static/img/4ae1c9ec91cd33a9b38ad741ac1d0a4f.png"></a>
                            <p>Free For All</p>
                        </div>
                        <div class="template" placeid="95205458">
                            <a class="game-image"><img class="" src="/static/img/f6e818f03afa39b999a4ed33b464c0cb.png"></a>
                            <p>Team Deathmatch</p>
                        </div>
                </div>
            </div>
            <div id="MyProjectsView" class="welcome-content-area" style="display: none">
                <h2>My Published Projects</h2>
                <div id="AssetList">


    <div>
        <span>You must be logged in to view your published projects!</span>
    </div>
    <script type="text/javascript">
        $('#MyProjects').click(function() {
            $('#header-login').addClass('active');
            $('#iFrameLogin').css('display', 'block');
        });
    </script>
                </div>        
            </div>
            <div id="ButtonRow" class="divider-top divider-left divider-bottom">
                <a class="btn-medium btn-primary" id="EditButton">Edit<span class="btn-text">Edit</span></a>
                <a class="btn-medium btn-primary" id="BuildButton">Build<span class="btn-text">Build</span></a>
                <a class="btn-medium btn-negative" id="CollapseButton">Cancel<span class="btn-text">Cancel</span></a>
            </div>
        </div>
    </div>
    
    <div class="GenericModal modalPopup unifiedModal smallModal" style="display:none;">
        <div class="Title"></div>
        <div class="GenericModalBody">
            <div>
                <div class="ImageContainer">
                    <img class="GenericModalImage" alt="generic image" src="/static/img/warning.png">
                </div>
                <div class="Message"></div>
            </div>
            <div class="clear"></div>
            <div id="GenericModalButtonContainer" class="GenericModalButtonContainer">
                <a class="ImageButton btn-neutral btn-large roblox-ok">OK<span class="btn-text">OK</span></a>
            </div>  
        </div>
    </div>
    <script type="text/javascript">
        $(function () {
    
            Roblox.Client.Resources = {
                //<sl:translate>
                here: "here",
                youNeedTheLatest: "You need Our Plugin for this.  Get the latest version from ",
                plugInInstallationFailed: "Plugin installation failed!",
                errorUpdating: "Error updating: "
                //</sl:translate>
            };

            if (typeof Roblox.IDEWelcome === "undefined")
                Roblox.IDEWelcome = { };

            Roblox.IDEWelcome.Resources = {
                //<sl:translate>
                openProject: "Open Project",
                openProjectText: "To open your project, open to this page in ",
                robloxStudio: "ROBLOX Studio",
                editPlace: "Edit Place",
                toEdit: "To edit ",
                openPage: ", open to this page in ",
                buildPlace: "Build Place",
                toBuild: "To build on ",
                placeInactive: "Place Inactive",
                activate: ", activate this place by going to File->My Published Projects.",
                emailVerifiedTitle: "Verify Your Email",
                emailVerifiedMessage: "You must verify your email before you can work on your place. You can verify your email on the <a href='/My/Account.aspx?confirmemail=1'>Account</a> page.",
                verify: "Verify",
                cancel: "Cancel"
                //</sl:translate>
            };
        });
    </script>
    
<div class="ConfirmationModal modalPopup unifiedModal smallModal" data-modal-handle="confirmation" style="display:none;">
    <a class="genericmodal-close ImageButton closeBtnCircle_20h"></a>
    <div class="Title"></div>
    <div class="GenericModalBody">
        <div class="TopBody">
            <div class="ImageContainer roblox-item-image" data-image-size="small" data-no-overlays="" data-no-click="">
                <img class="GenericModalImage" alt="generic image">
            </div>
            <div class="Message"></div>
        </div>
        <div class="ConfirmationModalButtonContainer">
            <a href="" roblox-confirm-btn=""><span></span></a>
            <a href="" roblox-decline-btn=""><span></span></a>
        </div>
        <div class="ConfirmationModalFooter">
        
        </div>  
    </div>  
    <script type="text/javascript">
        //<sl:translate>
        Roblox.GenericConfirmation.Resources = { yes: "Yes", No: "No" }
    //</sl:translate>
    </script>
</div>



</body></html>