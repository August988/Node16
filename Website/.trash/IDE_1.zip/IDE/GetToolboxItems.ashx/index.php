<?php
  header("Content-type: text/xml");
  //temp
  echo '<xml>
   <Item>
    <Name>Netural Spawn Location</Name>
    <Type>Model</Type>
    <Image>/static/img/unapprove-60x62.Png</Image>
    <AssetID>53326</AssetID>
   </Item>
  </xml>'
?>