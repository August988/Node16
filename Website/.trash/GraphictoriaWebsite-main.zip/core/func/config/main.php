<?php
	// This file contains all configuration.
	class config {
		public static function getName() {
			return "GWebsite";
		}
	}
?>
