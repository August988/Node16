# Graphictoria Website
This is what used to be Graphictoria 4's website. Keep in mind that the code is quite disgusting. This in no way represents how I develop websites nowadays.

# UPDATE
Graphictoria is back! You should check out <a href="https://gtoria.net" target="_blank">Graphictoria 5</a>!

Please do not use this source on your project / revival. The source currently has multiple vulnerbilites. If you want to go make your own old Roblox revival, i recommend learning PHP and some reverse engineering. Using Graphictoria's source code is not an option, since it can get taken down by <a href="https://github.com/Icseon">Icseon</a> (well, i don't know, but he tried to take down a revival using this source code before before).

