<?php

echo (bool)"false";