<?php

use Fobe\Web\WebContextManager;

$user->Logout();
WebContextManager::Redirect("/");