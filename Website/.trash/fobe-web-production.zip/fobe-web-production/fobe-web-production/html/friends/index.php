<?php
header("Location: view");
?>