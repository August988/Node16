<?php
header('Location: view');