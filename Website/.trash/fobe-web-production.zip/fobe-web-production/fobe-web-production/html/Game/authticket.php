<?php

//echo $_COOKIE['token'];
echo genTicket();