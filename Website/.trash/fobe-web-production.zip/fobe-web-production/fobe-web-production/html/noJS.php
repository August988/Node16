<?php

echo '
<html>
<body>
<div>Javascript must be enabled to visit Fobe!</div>
</body>
</html>
';