<?php
header('Content-Type: application/json');
echo json_encode(array(
    "gameAvatarType" => "MorphToR15"
), JSON_UNESCAPED_SLASHES);