<?php

use Fobe\Web\WebContextManager;

WebContextManager::Redirect(getCurrentThemeLogo());