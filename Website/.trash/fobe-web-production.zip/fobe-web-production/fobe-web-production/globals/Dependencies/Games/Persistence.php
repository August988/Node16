<?php

/*
    Fobe 2021
*/

namespace Fobe\Games {
    class Persistence
    {

    }
}
