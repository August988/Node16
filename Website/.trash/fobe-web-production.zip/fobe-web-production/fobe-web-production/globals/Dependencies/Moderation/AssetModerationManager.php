<?php

namespace Fobe\Moderation {
    use PDO;

    class AssetModerationManager
    {

    }
}