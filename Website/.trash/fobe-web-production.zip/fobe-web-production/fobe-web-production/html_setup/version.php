<?php

echo $ws->AlphalandVersion;