<?php

echo $ws->AlphalandStudioVersion;