<?php

echo '{"ExeVersion": "'.$ws->GameFileVersion.'", "ValidateInstalledExeVersion": "True", "ShowInstallSuccessPrompt": "True"}';