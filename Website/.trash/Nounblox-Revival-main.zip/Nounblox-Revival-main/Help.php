<?php
include $_SERVER["DOCUMENT_ROOT"].'/core/header.php';
include $_SERVER["DOCUMENT_ROOT"].'/core/nav.php';
require_once $_SERVER["DOCUMENT_ROOT"].'/core/config.php';
?>
<h1> Hello, fellow user. Read these rules. </h1>
<h1> Everyone knows this, be respectful to every admin on site or discord. </h1>
<h1> You need to be +13 years old or older, if you are underage you will be IP-Banned from this site. </h1>
<h1> Dont beg for keys, some admins will ignore you for sure, just wait for an keydrop or get invited by an friend. </h1>
<h1> YOU, are responsible if the user you invited makes shit, you will be warned. </h1>

<h1> Thank you for joining NOUNBLOX, the site credits are NiceYomi, RBXLHub (shared some codes), and our staff members, Thank you! </h1>
