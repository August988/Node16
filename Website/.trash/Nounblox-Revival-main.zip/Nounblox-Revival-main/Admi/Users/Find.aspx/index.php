
<?php
session_start();
include("../../includes/prestart.php");
?>

							<p style="display: inline">User Name</p>
							<input style="display: inline">
							<p style="display: inline"></p>
							<button style="display: inline">Search By Username</button>
							<p></p>
							<hr>
							<p></p>
							<p style="display: inline">User ID</p>
							<input style="display: inline">
							<p style="display: inline"></p>
							<button style="display: inline">Search By User ID</button>
							<p></p>
							<hr>
							<p></p>
							<p style="display: inline">Email Address</p>
							<input style="display: inline">
							<p style="display: inline"></p>
							<button style="display: inline">Search By Email Address</button>
							<p></p>
							<hr>
							<p>User Search Results</p>
							<p></p>
