<?php
include $_SERVER["DOCUMENT_ROOT"].'/core/header.php';
include $_SERVER["DOCUMENT_ROOT"].'/core/nav.php';
require_once $_SERVER["DOCUMENT_ROOT"].'/core/config.php';
?>
<style>.Navigation{display:none!important;}#Alerts{display:none!important;}#Authentication{display:none!important;}#Settings{display:none!important;}</style>
<br>
<br>
<br>
<br>
<h2 style="text-align:center">Nounblox currently does not support other languages.</h2>
<br>
<h2 style="text-align:center">Please use google translator.</h2>
<br>
<h2 style="text-align:center">https://chrome.google.com/webstore/detail/google-translate/aapbdbdomjkkjkaonfhkkikfgjllcleb/related?hl=en</h2>
<br>
<br>
<br>
<br>
<?
include 'core/footer.php';
?>