<?php
define('DB_SERVER', '127.0.0.1');
define('DB_USERNAME', 'nounblx');
define('DB_PASSWORD', '3myhnqpe');
define('DB_NAME', 'nounblx');

$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);