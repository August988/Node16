<?php
//pretty charapps made by sojdfvahdafihdgsdfds
  
header("content-type:text/plain");

$shirt = addslashes($_GET["shirt"]);
$pants = addslashes($_GET["pants"]);
$tshirt = addslashes($_GET["tshirt"]);

ob_start();
?>

http://www.nounblx.cf/asset/?id=;http://www.nounblx.cf/asset/?id=<?php echo $pants; ?>;http://www.nounblx.cf/asset/?id=<?php echo $shirt; ?>;http://www.nounblx.cf/asset/?id=<?php echo $tshirt; ?>;