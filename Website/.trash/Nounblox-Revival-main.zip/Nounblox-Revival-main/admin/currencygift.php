<?php include('include.php'); ?>
<center>
<a href="index.php"><h1 style="color: black;">< Back</h1></a>
    <a style="color: blue;" href="buxcurrencygift.php">NOUNBUX</a><br>
    <a style="color: blue;" href="tixcurrencygift.php">TICKETS</a><br>
</center>
<?php include('finclude.php'); ?>