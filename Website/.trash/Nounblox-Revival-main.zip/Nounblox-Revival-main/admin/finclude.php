<?php include($_SERVER["DOCUMENT_ROOT"]."/core/footer.php");
?>