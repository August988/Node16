

<a href="/blog/?paged=2">Next Page &raquo;</a>
</div><div id="sidebar"><p /><p><br clear="all" /><p /><ul>
 <li id="search">   <h2>Search</h2>
   <form id="searchform" method="get" action="/index.php">	<div>		<input type="text" name="s" id="s" size="15" />		<input type="submit" value="Search" />	</div>	</form> </li>	
	  <li id="linkcat-10" class="linkcat"><h2><?=$sitename;?></h2>
	<ul>
<li><a href="/info/Privacy.aspx" title="Privacy Policy">Privacy Policy</a></li>

	</ul>
</li>

 <li id="categories"><h2>Categories</h2>
	<ul>		<li class="cat-item cat-item-1"><a href="/blog/?cat=1" title="General <?=$sitename;?> news">News</a>
<ul class='children'>
	<li class="cat-item cat-item-2"><a href="/blog/?cat=2" title="Discussion of technical issues related to the development of <?=$sitename;?>">Bits and Bytes</a>
</li>
	<li class="cat-item cat-item-8"><a href="/blog/?cat=8" title="Announcements, updates, and results of <?=$sitename;?> building contests.">Contests</a>
</li>
	<li class="cat-item cat-item-5"><a href="/blog/?cat=5" title="Discussion of features so new they haven&#039;t even made it to alpha status">Deep Alpha</a>
</li>
	<li class="cat-item cat-item-3"><a href="/blog/?cat=3" title="Discussion relating to <?=$sitename;?> design decisions">Design Docs</a>
</li>
	<li class="cat-item cat-item-4"><a href="/blog/?cat=4" title="Find out what is new in the current release of <?=$sitename;?>">Release Notes</a>
</li>
	<li class="cat-item cat-item-6"><a href="/blog/?cat=6" title="Articles written by our users">Reports From <?=$sitename;?>ia</a>
</li>
	<li class="cat-item cat-item-7"><a href="/blog/?cat=7" title="Explorations of <?=$sitename;?>ia">Travelogue</a>
</li>
</ul>
</li>

	</ul> </li> <li id="archives"><h2>Archives</h2>
 	<ul>	 	<li><a href='/blog/?m=200901' title='January 2009'>January 2009</a></li>
	<li><a href='/blog/?m=200812' title='December 2008'>December 2008</a></li>
	<li><a href='/blog/?m=200811' title='November 2008'>November 2008</a></li>
	<li><a href='/blog/?m=200810' title='October 2008'>October 2008</a></li>
	<li><a href='/blog/?m=200809' title='September 2008'>September 2008</a></li>
	<li><a href='/blog/?m=200808' title='August 2008'>August 2008</a></li>
	<li><a href='/blog/?m=200807' title='July 2008'>July 2008</a></li>
	<li><a href='/blog/?m=200806' title='June 2008'>June 2008</a></li>
	<li><a href='/blog/?m=200805' title='May 2008'>May 2008</a></li>
	<li><a href='/blog/?m=200804' title='April 2008'>April 2008</a></li>
	<li><a href='/blog/?m=200803' title='March 2008'>March 2008</a></li>
	<li><a href='/blog/?m=200802' title='February 2008'>February 2008</a></li>
	<li><a href='/blog/?m=200801' title='January 2008'>January 2008</a></li>
	<li><a href='/blog/?m=200712' title='December 2007'>December 2007</a></li>
	<li><a href='/blog/?m=200711' title='November 2007'>November 2007</a></li>
	<li><a href='/blog/?m=200710' title='October 2007'>October 2007</a></li>
	<li><a href='/blog/?m=200709' title='September 2007'>September 2007</a></li>
	<li><a href='/blog/?m=200708' title='August 2007'>August 2007</a></li>
	<li><a href='/blog/?m=200707' title='July 2007'>July 2007</a></li>
	<li><a href='/blog/?m=200706' title='June 2007'>June 2007</a></li>
	<li><a href='/blog/?m=200705' title='May 2007'>May 2007</a></li>
	<li><a href='/blog/?m=200704' title='April 2007'>April 2007</a></li>
	<li><a href='/blog/?m=200703' title='March 2007'>March 2007</a></li>
	<li><a href='/blog/?m=200702' title='February 2007'>February 2007</a></li>
	<li><a href='/blog/?m=200701' title='January 2007'>January 2007</a></li>
	<li><a href='/blog/?m=200612' title='December 2006'>December 2006</a></li>

 	</ul> </li> <li id="meta"><h2>Meta</h2>
 	<ul>		<li><a href="/blog/wp-login.php?action=register">Register</a></li>
		<li><a href="/blog/wp-login.php">Log in</a></li>		<li><a href="feed:/blog/?feed=rss2" title="Syndicate this site using RSS"><abbr title="Really Simple Syndication">RSS</abbr></a></li>		<li><a href="feed:/blog/?feed=comments-rss2" title="The latest comments to all posts in RSS">Comments <abbr title="Really Simple Syndication">RSS</abbr></a></li>		<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform."><abbr title="WordPress">WP</abbr></a></li>		
	</ul> </li> 			
 
</ul></div>
<div id="footer">	<p>		<?=$sitename;?> Developers&#8217; Journal is powered by		<a href="http://wordpress.org/">WordPress</a> and a thousand networked Amigas	</p>	<p class="rights-reserved">		All rights reserved 2006	</p><script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script> <script type="text/javascript">_uacct="UA-486632-1"; _udn="roblox.com"; urchinTracker();</script></div>	</div>
</body></html>