<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head profile="http://gmpg.org/xfn/11">	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />	<title>Nounblox Developers&#8217; Journal</title>		<meta name="generator" content="WordPress 2.6.1" /> <!-- leave this for stats please -->	<style type="text/css" media="screen">		@import url( http://blog.roblox.com/wp-content/themes/earth-10/style.css );	</style>	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://blog.roblox.com/?feed=rss2" />	<link rel="alternate" type="text/xml" title="RSS .92" href="http://blog.roblox.com/?feed=rss" />	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="http://blog.roblox.com/?feed=atom" />		<link rel="pingback" href="http://blog.roblox.com/xmlrpc.php" />    	<link rel='archives' title='January 2009' href='http://blog.roblox.com/?m=200901' />
	<link rel='archives' title='December 2008' href='/blog/?m=200812' />
	<link rel='archives' title='November 2008' href='/blog/?m=200811' />
	<link rel='archives' title='October 2008' href='/blog/?m=200810' />
	<link rel='archives' title='September 2008' href='/blog/?m=200809' />
	<link rel='archives' title='August 2008' href='/blog/?m=200808' />
	<link rel='archives' title='July 2008' href='/blog/?m=200807' />
	<link rel='archives' title='June 2008' href='/blog/?m=200806' />
	<link rel='archives' title='May 2008' href='/blog/?m=200805' />
	<link rel='archives' title='April 2008' href='/blog/?m=200804' />
	<link rel='archives' title='March 2008' href='/blog/?m=200803' />
	<link rel='archives' title='February 2008' href='/blog/?m=200802' />
	<link rel='archives' title='January 2008' href='/blog/?m=200801' />
	<link rel='archives' title='December 2007' href='/blog/?m=200712' />
	<link rel='archives' title='November 2007' href='/blog/?m=200711' />
	<link rel='archives' title='October 2007' href='/blog/?m=200710' />
	<link rel='archives' title='September 2007' href='/blog/?m=200709' />
	<link rel='archives' title='August 2007' href='/blog/?m=200708' />
	<link rel='archives' title='July 2007' href='/blog/?m=200707' />
	<link rel='archives' title='June 2007' href='/blog/?m=200706' />
	<link rel='archives' title='May 2007' href='/blog/?m=200705' />
	<link rel='archives' title='April 2007' href='/blog/?m=200704' />
	<link rel='archives' title='March 2007' href='/blog/?m=200703' />
	<link rel='archives' title='February 2007' href='/blog/?m=200702' />
	<link rel='archives' title='January 2007' href='/blog/?m=200701' />
	<link rel='archives' title='December 2006' href='/blog/?m=200612' />


<style type="text/css" media="screen">

		@import url( /blog/wp-content/themes/earth-10/style.css );

	</style>

	
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="/blog/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="/blog/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 2.6.1" />


</head><body><div id="container"><div id="header">	<div id = "headerlogo">		<a href="/" style="display:inline-block;height:70px;width:267px;cursor:pointer;">		<img src="/images/logo-1.png" border="0"/></a>	</div>	<h1><a href="/blog"><?=$sitename;?> Developers&#8217; Journal</a></h1>	<!--<h2>The Roblog</h2> --></div><div id="content">

	