<?php
include $_SERVER["DOCUMENT_ROOT"].'/core/header.php';
include $_SERVER["DOCUMENT_ROOT"].'/core/nav.php';
require_once $_SERVER["DOCUMENT_ROOT"].'/core/config.php';
?>
<div class="Exclamation">
            </div>
<h1> Watcha doing here, underage? This is a roblox revival, not for kids! Visit Roblox and play there, grr! </h1>
