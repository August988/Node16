<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<?php include '../core/config.php' ?>

<html xmlns="http://www.w3.org/1999/xhtml">
<link rel="stylesheet" type="text/css" href="/css/banner-styles.css?v=fantwOh2" />
<link rel="stylesheet" type="text/css" href="/css/iconochive.css?v=qtvMKcIJ" />
<!-- End Wayback Rewrite JS Include -->
<title>
  <?=$sitename?> Help
</title><link rel="stylesheet" type="text/css" href="/RobloxOld.css"/></head>
<body>
<style type="text/css">
body {
  margin-top:0 !important;
  padding-top:0 !important;
}
</style>
    <form name="form1" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" id="form1">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTcyNTU0NTIyMWRkiBouXtm3xy1HkqbaCiS2DhaXTPA="/>

        <p>
            Besides using simple blocks, you can insert Things that other people have built into your Place. Use the Insert... menu in the game to browse.</p>
        <table id="Table1" class="Help">
            <tr style="font-weight: bold">
                <td>
                    Action</td>
                <td>
                    Primary</td>
                <td>
                    Alternate</td>
            </tr>
            <tr>
                <td>
                    Move Character</td>
                <td>
                    Arrow keys</td>
                <td>
                    ASDW keys</td>
            </tr>
            <tr>
                <td>
                    Move Character (no tool selected)</td>
                <td>
                    Click location with green disk</td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Jump</td>
                <td>
                    Space Bar</td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Look up/down/left/right</td>
                <td>
                    Right-click and drag mouse</td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Look side to side</td>
                <td>
                    Move mouse to the far right or far left
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Zoom in/out and up/down</td>
                <td>
                    Mouse wheel</td>
                <td>
                    I (in) and O (out) keys</td>
            </tr>
            <tr>
                <td>
                    Change Tool / Toggle tool on off</td>
                <td>
                    Number keys 1, 2, 3, ...</td>
                <td>
                    Click on the tool</td>
            </tr>
            <tr>
                <td>
                    Drop Tool</td>
                <td>
                    Backspace key</td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Drop Hat</td>
                <td>
                    Equal (=) key</td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Regenerate dead or stuck character</td>
                <td>
                    Character regenerates automatically</td>
                <td>
                    Exit and then return to the Place</td>
            </tr>
            <tr>
                <td>
                    First Person Mode</td>
                <td>
                    Zoom all the way in</td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                </td>
                <td>
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                </td>
                <td>
                </td>
                <td>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
