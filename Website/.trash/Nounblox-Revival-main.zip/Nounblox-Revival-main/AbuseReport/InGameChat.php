<title>Abuse Report</title>
<center>Report an abusive player in the discord server</center>