---Change to true to force new chat on.
return false
